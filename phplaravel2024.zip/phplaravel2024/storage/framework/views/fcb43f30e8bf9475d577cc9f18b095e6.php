

<?php $__env->startSection('content'); ?>

  <h1>ver grupo</h1>
    <div class="row">
        <div class="col-md-4">
            <label for="nombre" class="form-label">Nombre</label>
            <input type="text" class="form-control" id="nombre" name="nombre" value="<?php echo e($grupo->nombre); ?>" disabled>
        
        </div>

    </div>
    <div class="row">
        <div class="col-md-6">
            <label for="descripcion" class="form-label">Descripcion</label>
            <textarea  class="form-control" id="descripcion" name="descripcion" disabled><?php echo e($grupo->descripcion); ?></textarea>
        
        </div>

    </div>
    <br>
    <div class="row">
        <div class="col-md-12">
           
            <a href="<?php echo e(route('grupos.index')); ?>" class="btn btn-secondary">Retornar</a>
        
        </div>

    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MINEDUCYT\Herd\phplaravel\phplaravel2024\resources\views/grupos/show.blade.php ENDPATH**/ ?>
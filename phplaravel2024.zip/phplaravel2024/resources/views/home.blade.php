@extends('layouts.app')

@section('content')
  <div class="alert alert-success" role="alert">
    bienvenido


  </div>
@endsection